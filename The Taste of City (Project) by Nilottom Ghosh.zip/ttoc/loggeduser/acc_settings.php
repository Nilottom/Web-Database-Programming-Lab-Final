<?php

include("../controller/config.php");
session_start();

$user=$_SESSION['User'];
if (isset($_SESSION['User'])) {
    
    echo '';
}
else {
     header("location:../login.php");
}

$email=$_SESSION['User'];
$sql="SELECT * FROM userinfo WHERE email='$email'";
$result=mysqli_query($myconn,$sql);
$fdata=mysqli_fetch_array($result);

$uname=$fdata['name'];
$uemail=$fdata['email'];
$uphone=$fdata['phone'];


?>

<!doctype html>

<html lang="en">
    
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
      
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      
    <title>The Taste of City - Foods at your Doorstep....</title>
      
      
      <style>
      
            #navigation {
              
              border-bottom: 2px outset #E7E7E8;
              background-color: white;
              font-weight: 500;
              
          }
          
          #jumbotron {
              
              background-image: url(../images/jumbtron.jpg);
              opacity: 10;
              color: white;
              text-shadow: 0 0 2px #000000, 0 0 2px #000000;
              font-weight: bold;
              
          }
          
          .fa {
                  font-size: 30px;
                  width: 30px;
                  text-decoration: none;
           }
          
          #body {
              
              position: relative;
              margin-top: 90px;
              
          }


      
      </style>
      
      
      
  </head>
    
  <body id="body">
      
      
      

        <nav class="navbar navbar-expand-lg navbar-light bg-none fixed-top" id="navigation">
          <a class="navbar-brand" href="../index.php"><img src="../images/site-logo.png"></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
              </li>
                
                                    <?php
                
                        if(isset($_SESSION['User']))
                        {
                            echo '';}
                else{
                    
                    
                
                echo '
                
                
              <li class="nav-item">
                <a class="nav-link" href="login.php">Sign In</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="registration.php">Sign Up</a>
              </li>
                  
                  ';
                
                }
                
                ?>
                
                
                
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Our Kitchen
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#">Categories</a>
                  <a class="dropdown-item" href="../shop/foods.php">All Food Items</a>
                </div>
              </li>
                    <?php
                
                        if(isset($_SESSION['User']))
                        {
                            echo '
                            
                                <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Order
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="../shop/cart.php">Cart</a>
                                  <a class="dropdown-item" href="../shop/placeorder.php">Checkout</a>
                                </div>
                              </li>
                              
                               <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <i class="fa fa-user-circle" style="font-size: 17px;"></i>My Account
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="../loggeduser/profile.php">Profile</a>
                                  <a class="dropdown-item" href="../loggeduser/edit_profile.php">Edit Profile</a>
                                  <a class="dropdown-item" href="../model/logout.php?logout">Log Out</a>
                                </div>
                              </li>
                            
                            ';
                        }

                    ?>
            </ul>
            <form class="form-inline my-2 my-lg-0" action="../model/search.php" method="POST">
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
              <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search Items</button>
            </form>
          </div>
        </nav>
      <!-- Navigation Bar ends here -->
      
      
      
      
      
      <div class="container">
          <div class="row">
              <div class="col-sm-4" style="background-color:;">
                  <br><br><br><br>
                  <a href="profile.php" style="text-decoration: none;"><button type="button" class="btn btn-info btn-lg btn-block">Profile</button></a>
                  <br>
                  <a href="acc_settings.php" style="text-decoration: none;"><button type="button" class="btn btn-info btn-lg btn-block"><strong>Account Settings</strong></button></a>
                  <br>
                  <a href="edit_profile.php" style="text-decoration: none;"><button type="button" class="btn btn-info btn-lg btn-block">Edit Profile</button></a>
                  <br>
                  <a href="../model/logout.php?logout" style="text-decoration: none;"><button type="button" class="btn btn-info btn-lg btn-block">Log Out</button></a>
                  <br>
                  
              
                  
                  
              
              </div>
              <div class="col-sm-2"></div>
              
              <div class="col-sm-4" style="background-color: #F2F2F2; margin-top:40px;">
                  <br><br>
                  
                  <form action="../model/pwupdate.php" method="POST" enctype="multipart/form-data">
                      
                      
                      <div class="form-group">
                        <label for="name">Current Password</label>
                        <input type="password" class="form-control" id="passwordc" name="passwordc">
                      </div>
                      <div class="form-group">
                        <label for="name">New Password</label>
                        <input type="password" class="form-control" id="passwordn1" name="passwordn1">
                      </div>
                      <div class="form-group">
                        <label for="name">Retype New Password</label>
                        <input type="password" class="form-control" id="passwordn2" name="passwordn2">
                      </div>
                      <div class="form-group">
                        <button class="btn btn-info" type="submit">Update</button>
                      </div>
                      
                      
                      <a href="../model/acc_del.php?usr=<?php print_r($user);  ?>" style="color:red;">Delete Account permanently</a>
                      <p></p>
                    </form>
                  
                  
              </div>
          </div>
      </div>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

      
      
      
      

      
      
      
      

      <div class="container-fluid" style="margin-top: 100px; background-color: black;">
          <div class="row">
          <div class="col-sm-4">
          <img src="../images/site-logo-footer.png">
          <address style="color: aqua; font-weight: lighter;">
                Developed by <a href="mailto:nilottom@gmail.com">Nilottom Ghosh</a>.<br>
                ©Copyright: www.thetasteofcity.com<br>
                Our Address: 816, Rathkhola, Kishoreganj-2300,<br>
                Bangladesh.
          </address>
          </div>
              
          <div class="col-sm-4" style="margin-top: 20px; color: aqua;">
             <p>Find Us At :</p>
              <a href="#" class="fa fa-facebook"></a>
              <a href="#" class="fa fa-twitter"></a>&nbsp;&nbsp;
              <a href="#" class="fa fa-youtube"></a>&nbsp;&nbsp;
              <a href="#" class="fa fa-instagram"></a>
              
              
              <br><br>
              <p>Download Our App From:</p>
              <a href="#"><img src="../images/playstore-icon.png" width="120" height="46"></a>
              
          </div>
              
            <div class="col-sm-4" style="margin-top: 20px; color: aqua;">
                
                <p><img src="https://img.icons8.com/nolan/64/000000/service.png" width="24" height="24"> Need Help:</p>
                <p>We are always here to help you 24/7. Contact us for any queery, complain or anything else.</p>
                <p>Phone: 01779040805</p>
                <p>Email: <a href="mailto:nilottom@gmail.com">nilottom@gmail.com</a></p>
              
          </div>
              
      </div>
      </div>
      
      
      
      <!-- Footer ends here -->
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>