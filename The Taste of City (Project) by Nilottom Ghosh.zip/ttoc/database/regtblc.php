<?php

include("../controller/config.php");

$tbl_reg="CREATE TABLE IF NOT EXISTS	userinfo(
userid INT(11) NOT NULL auto_increment,
PRIMARY KEY(userid),
name VARCHAR(50) NOT NULL,
password VARCHAR(13) NOT NULL,
email  VARCHAR(13) NOT NULL,
phone  VARCHAR(18) NOT NULL
)";
$regtblc=mysqli_query($myconn,$tbl_reg);

if($regtblc===TRUE)
{
	echo "userinfo tabel created ):";
}
else
{
		echo "userinfo tabel not created (:";

}

?>