<?php
include("../controller/config.php");


$sql="CREATE TABLE IF NOT EXISTS cart (

cart_id INT(255) NOT NULL auto_increment,
PRIMARY KEY (cart_id),
user_email VARCHAR(255)


)";

$result=mysqli_query($myconn, $sql);

if ($result===TRUE) {

    echo 'table created';
}

else {
    
    echo 'table not created';
    
}

?>