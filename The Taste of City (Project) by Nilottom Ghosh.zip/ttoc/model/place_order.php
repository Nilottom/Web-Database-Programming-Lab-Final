<?php
include("../controller/config.php");
session_start();
$usr=$_SESSION['User'];

$sql="SELECT * FROM cart WHERE user_email='$usr'";
$result=mysqli_query($myconn, $sql);


while($fdata=mysqli_fetch_array($result)) {

$for_itms=array($fdata['product_id']);
$unc_or_itms=implode($for_itms);
$qty=$fdata['quantity'];

print_r ($unc_or_itms);

    
    $sql2="INSERT INTO order_info(ordered_by, ordered_items, quantity) VALUES ('$usr','$unc_or_itms','$qty')";
    $result2=mysqli_query($myconn, $sql2);
    
    
    
}


if ($result2===TRUE) {
    
    
    $sql3="DELETE FROM cart WHERE user_email='$usr'";
    $result4=mysqli_query($myconn, $sql3);
    
    
    header("location:../shop/placeorder.php");
    
}



?>

                  