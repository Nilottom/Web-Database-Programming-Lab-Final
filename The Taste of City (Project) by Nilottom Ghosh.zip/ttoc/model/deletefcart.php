<?php
include("../controller/config.php");

$cid=$_GET['cid'];

$sql="DELETE FROM cart WHERE cart_id='$cid'";
$result=mysqli_query($myconn, $sql);

if ($result===TRUE) {
    
    header("location:../shop/cart.php?del=success");
    
}
else {
    
    echo 'error';
    
}


?>