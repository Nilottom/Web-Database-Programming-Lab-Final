<?php
include("../controller/config.php");

$name=$_POST['name'];
$password=md5($_POST['password']);
$email=$_POST['email'];
$phone=$_POST['phone'];

$fdata="SELECT * FROM userinfo WHERE email='$email'";
$result1=mysqli_query($myconn,$fdata);

$dataf=mysqli_fetch_array($result1);
$ndemail=$dataf['email'];
$ndphone=$dataf['phone'];

if ($ndemail==$email || $ndphone==$phone) {
    
    
    header("location:../registration.php?Empty=email or phone error");

}

else {
    
    $sql="INSERT INTO userinfo(name, password, email, phone) VALUES('$name' , '$password' , '$email' , '$phone')";
    
    $result2=mysqli_query($myconn,$sql);
if($result2===TRUE)
{
    
	header("location:../login.php");
}
else
{
	echo "registration fail";
	}

}

?>