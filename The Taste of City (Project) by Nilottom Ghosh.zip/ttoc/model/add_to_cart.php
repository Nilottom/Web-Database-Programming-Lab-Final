<?php

include("../controller/config.php");
session_start();

$email=$_SESSION['User'];
@$acpro_id=$_GET['pro_id'];


$sql1="SELECT * FROM products WHERE product_id='$acpro_id'";
$result1=mysqli_query($myconn, $sql1);
$fdata1=mysqli_fetch_array($result1);


$sql2="SELECT * FROM userinfo WHERE email='$email'";
$result2=mysqli_query($myconn, $sql2);
$fdata2=mysqli_fetch_array($result2);

                        //customer info

$cname=$fdata2['name'];
$cemail=$fdata2['email'];
$cphone=$fdata2['phone'];

                        //product info

$pro_id=$fdata1['product_id'];
$acuser_email=$email;

$sqltv="SELECT * FROM cart WHERE user_email='$email'";
$resulttv=mysqli_query($myconn, $sqltv);
$fdatatv=mysqli_fetch_array($resulttv);
$pro_idtv=$fdatatv['product_id'];
$usr_idtv=$fdatatv['user_email'];

if ($usr_idtv==$email && $pro_idtv==$acpro_id || $acpro_id==0) {

echo '';

}
else {

$sql3="INSERT INTO cart (user_email, product_id) VALUES ('$acuser_email','$pro_id')";
$result3=mysqli_query($myconn, $sql3);
    
    
    if($result3===TRUE) {
        
        header("location:../shop/cart.php");

    }
    
    else {
        
        echo 'failed to add to cart';
        
    }
                            

}


?>