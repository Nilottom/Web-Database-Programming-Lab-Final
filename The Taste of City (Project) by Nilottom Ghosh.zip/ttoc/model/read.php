<?php
include("../controller/config.php");
session_start();

$email=$_POST['email'];
$password=md5($_POST['password']);
$reffer=$_GET['from_foods'];

$sql="SELECT * FROM userinfo WHERE email='$email' AND password='$password'";

$result=mysqli_query($myconn,$sql);

$row=mysqli_fetch_array($result);
$femail=$row['email'];
$fpassword=$row['password'];

if ($femail==$email && $fpassword==$password) {
    
    $_SESSION['User']=$_POST['email'];
    header("location:../index.php");
    echo ($reffer);
    
}

else if ($femail==$email && $fpassword==$password && $reffer==true) {
    
    $_SESSION['User']=$_POST['email'];
    header("location:../shop/foods.php");
    
}

else {
    
    header("location:../login.php?Error=Incorrect_info");
}