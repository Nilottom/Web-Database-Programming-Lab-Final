<?php
include("../controller/config.php");
session_start();
@$user=$_SESSION['User'];
$sql="SELECT * FROM userinfo WHERE email='$user'";

$result=mysqli_query($myconn, $sql);
$fdata=mysqli_fetch_array($result);

$dp=$fdata['user_dp'];

$file = "$dp";
echo basename($file);


?>