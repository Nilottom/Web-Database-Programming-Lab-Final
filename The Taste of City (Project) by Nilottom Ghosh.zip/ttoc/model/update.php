<?php

include("../controller/config.php");

$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];

$dp=$_FILES['dp']['name'];
$dp_temp=$_FILES['dp']['tmp_name'];
$dir="../images/user_dp/".$dp;
move_uploaded_file($dp_temp, $dir);


$sql="UPDATE userinfo SET name='$name', email='$email', phone='$phone', user_dp='$dir' WHERE email='$email'";
$result=mysqli_query($myconn, $sql);

if($result===TRUE) {
    
    header("location:../loggeduser/profile.php?success= true");
    
}

else {
    
    echo 'Error in updationg profile';
    
}








?>