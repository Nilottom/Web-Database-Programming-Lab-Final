<?php
include("../controller/config.php");
session_start();

@$cemail=$_GET['usr'];

$sql="DELETE FROM userinfo WHERE email='$cemail'";
$result=mysqli_query($myconn, $sql);

if($result===TRUE) {
    session_destroy();
    header("location:../index.php");
}

?>