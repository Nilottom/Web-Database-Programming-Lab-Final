<?php
include("../controller/config.php");
session_start();
$user=$_SESSION['User'];


$sql="SELECT * FROM `order_info` WHERE `ordered_by`='$user'";
$result=mysqli_query($myconn, $sql);

while($fdata=mysqli_fetch_array($result)) {
    
    $ordered_items=$fdata['ordered_items'];
    $qty=$fdata['quantity'];
    
    
    $sql2="SELECT * FROM products WHERE product_id='$ordered_items'";
    $result2=mysqli_query($myconn, $sql2);
    $fdata2=mysqli_fetch_array($result2);
    
    $pro_name=$fdata2['product_name'];
    $pro_price=$fdata2['product_price'];
    
    $spro_total=$qty*$pro_price;
    
    
    
    print_r($spro_total);
    
    
    
}







?>
