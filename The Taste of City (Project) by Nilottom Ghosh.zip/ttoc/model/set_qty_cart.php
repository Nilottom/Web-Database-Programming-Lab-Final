<?php
include("../controller/config.php");
session_start();

$usr=$_SESSION['User'];
$pro_id=$_GET['pro_id'];
$qty=$_POST['qty'];

//echo($qty);
$sql="UPDATE cart SET quantity='$qty' WHERE product_id='$pro_id'";
$result=mysqli_query($myconn, $sql);

if($result===TRUE) {
    
    header("location:../shop/cart.php");
    
}
else {
    
    echo 'failed';
    
}


?>