<?php
include("../controller/config.php");
session_start();

$identifier=$_SESSION['User'];

$passwordc=md5($_POST['passwordc']);
$passwordn1=md5($_POST['passwordn1']);
$passwordn2=md5($_POST['passwordn2']);

$sql1="SELECT * FROM userinfo WHERE email='$identifier'";

$result1=mysqli_query($myconn, $sql1);

$fdata=mysqli_fetch_array($result1);

$fpasswordc=$fdata['password'];


if($fpasswordc==$passwordc) {
    
    if($passwordn1==$passwordn2) {
        
        $sql2="UPDATE userinfo SET password='$passwordn2' WHERE email='$identifier'";
        $result2=mysqli_query($myconn, $sql2);
        
        if($result2===TRUE){
            echo'Password Updated';
        }
        else {
            echo 'Not Updated';
        }
        
    }
    else {
        
        echo 'Not matched';
    }
    
    
}

else {
    
    echo 'false';
    
    
}


?>