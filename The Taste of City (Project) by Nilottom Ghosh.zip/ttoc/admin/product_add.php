<?php

include("../controller/config.php");
/*session_start();

if (isset($_SESSION['User'])) {
    
    echo '';
}
else {
     header("location:../login.php");
}

$email=$_SESSION['User'];*/

$pro_img=$_FILES['pro_img']['name'];
$pro_img_tmp=$_FILES['pro_img']['tmp_name'];
$dir="../images/product_images/".$pro_img;
move_uploaded_file($pro_img_tmp, $dir);
    
$pro_name=$_POST['pro_name'];
$pro_cat=$_POST['pro_cat'];
$pro_price=$_POST['pro_price'];
$pro_det=$_POST['pro_det'];


$sql="INSERT INTO products (product_name, product_category, product_price, product_details, product_image) VALUES ('$pro_name','$pro_cat','$pro_price','$pro_det','$dir')";
$result=mysqli_query($myconn,$sql);

if($result===TRUE){
    
    echo'Product added';
}
else {
    
    echo'Product not added';
}


?>

<!doctype html>

<html lang="en">
    
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
      
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      
    <title>The Taste of City - Foods at your Doorstep....</title>
      
      
      <style>
      
            #navigation {
              
              border-bottom: 2px outset #E7E7E8;
              background-color: white;
              font-weight: 500;
              
          }
          
          #jumbotron {
              
              background-image: url(../images/jumbtron.jpg);
              opacity: 10;
              color: white;
              text-shadow: 0 0 2px #000000, 0 0 2px #000000;
              font-weight: bold;
              
          }
          
          .fa {
                  font-size: 30px;
                  width: 30px;
                  text-decoration: none;
           }
          
          #body {
              
              position: relative;
              margin-top: 90px;
              
          }


      
      </style>
      
      
      
  </head>
    
  <body id="body" style="margin-left: 400px;">
      
      <h1>Product Control Panel (Add Product)</h1>
      
              <div class="col-sm-2"></div>
              
              <div class="col-sm-4" style="background-color: #F2F2F2; margin-top:40px;">
                  <br><br>
                  
                  <form action="" method="POST" enctype="multipart/form-data">
                      
                      
                      <div class="form-group">
                        <label for="pro_img">Product Image:</label>
                        <input type="file" class="form-control-file" id="pro_img" name="pro_img">
                      </div>
                      <div class="form-group">
                        <label for="pro_name">Product Name</label>
                        <input type="text" class="form-control" id="pro_name" name="pro_name">
                      </div>
                       <div class="form-group">
                        <label for="pro_cat">Product Category</label>
                        <input type="text" class="form-control" id="pro_cat" name="pro_cat">
                      </div>
                      <div class="form-group">
                        <label for="pro_price">Product Price</label>
                        <input type="text" class="form-control" id="pro_price" name="pro_price">
                      </div>
                      <div class="form-group">
                        <label for="pro_det">Product Details</label>
                        <input type="text" class="form-control" id="pro_det" name="pro_det">
                      </div>
                      <div class="form-group">
                        <button class="btn btn-info" type="submit">Add Product</button>
                      </div>
                      
                    </form>
                  
                  
              </div>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

      
      
      
      

      
      

      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>